from flask import Flask,render_template,request,redirect
from cs50 import SQL


app=Flask(__name__)

db=SQL("sqlite:///lecture.db")



@app.route("/")
def index():
    return render_template("index.html")

@app.route("/register",methods=["GET","POST"])
def register():
    if request.method== "GET" :
        return render_template("register.html")

    else:
        email=request.form.get("email")
        if not email:
            return "<h1>you must enter email</h>"

        username=request.form.get("username")
        if not username:
            return "<h1>you must enter username"

        password=request.form.get("password")
        if not password:
            return "<h1>you must enter password</h1>"

        repassword=request.form.get("confpass")
        if not repassword:
            return "<h1>you must enter password confrim</h1>"

        if repassword!=password:
            return "<h1>password confrim not match</h1>"
        else:
            pass
        registerdata = db.execute("INSERT INTO user (username,password,email) VALUES ( :username , :password ,:email )",username=username, email=email,password=password)
        return redirect("/")

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method == "POST":

        if not request.form.get("username"):
            return render_template("error1.html",show = "-_- must provide username -_-")

        elif not request.form.get("password"):
            return render_template("error1.html",show = "-_- must provide password -_-")

        uservalid = db.execute("SELECT username FROM user")
        passvalid=db.execute("SELECT password FROM user")


        numpass = len(passvalid)
        numuser = len(uservalid)

        p = []
        u = []

        for b in range (0,numuser):
            u.append(uservalid[b]["username"])
            p.append(passvalid[b]["password"])

        for i in range (0,numuser):
            if request.form.get("username") == u[i]:
                 if request.form.get("password") == p[i]:
                     return redirect("/")
        return render_template("error1.html", show="-_- Invalid password or/and username -_-")
    else:
         return render_template("login.html")

@app.route("/products")
def product():
    return render_template("product.html")

@app.route("/product-details")
def product_details():
    return render_template("product_details.html")

@app.route("/card")
def card():
    return render_template("card.html")